// Gallery Pop Up

$(".popUp").magnificPopup({
    type: "image",
    gallery: {
      enabled: true,
    },
  });
  