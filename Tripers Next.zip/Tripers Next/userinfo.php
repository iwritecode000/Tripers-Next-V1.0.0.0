<?php 

$con = mysqli_connect('localhost','root');

if ($con) {
    echo "Connection Successful";
}else{
    "No Connection";
}

mysqli_select_db($con, 'tripersnext');

$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$message = $_POST['message'];

$query = "insert into userenquiry (name, email, mobile, message)
values ('$name', '$email', '$mobile', '$message')";

echo "$query";

mysqli_query($con, $query);

header('location:index.html')

?>